package database;

import client.*;
import friendlistUI.*;

public class Figures {
	public static final int ServerID = 2000000000;// ��������ID
	public static final int LoginID = 2000000001;// ��½�����ID��
	public static ChatClient cc;
	public static int IDNum;
	public static int Pic;
	public static String NickName;
	public static ListPane list;
	public static AddFriendPane afu;
	public static FriendListPane flu;
}
