package database;

import java.util.*;

import chatUI.*;

public class DialogDB {
	public static Map<String, DialogUI> dialogDB = new HashMap<String, DialogUI>();
}
