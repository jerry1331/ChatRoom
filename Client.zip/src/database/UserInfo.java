package database;

public class UserInfo {
	private int IDNum;// �������ID��
	private String nickName;// ������û����ǳ�
	private int avatar;

	/*
	 * �û�������Ϣ
	 */

	private byte collectionCount;// �����ж��������
	private String ListName[];// ����ÿ�����������
	private byte[] bodyCount;// ÿ���ж��ٸ���
	private int bodyNum[][];// ÿ������ID
	private int bodypic[][];// ����ͷ��
	private String bodyName[][];// ÿ�����ѵ��ǳ�

	public byte getCollectionCount() {
		return collectionCount;
	}

	public void setCollectionCount(byte listCount) {
		this.collectionCount = listCount;
	}

	public String[] getListName() {
		return ListName;
	}

	public void setListName(String[] listName) {
		ListName = listName;
	}

	public byte[] getBodyCount() {
		return bodyCount;
	}

	public void setBodyCount(byte[] bodyCount) {
		this.bodyCount = bodyCount;
	}

	public int[][] getBodyNum() {
		return bodyNum;
	}

	public void setBodyNum(int[][] bodyNum) {
		this.bodyNum = bodyNum;
	}

	public String[][] getBodyName() {
		return bodyName;
	}

	public void setBodyName(String[][] bodyName) {
		this.bodyName = bodyName;
	}

	public int getIDNum() {
		return IDNum;
	}

	public void setIDNum(int IDNum) {
		this.IDNum = IDNum;
	}

	public String getNickName() {
		return nickName;
	}

	public void setNickName(String nick) {
		nickName = nick;
	}

	public int[][] getBodypic() {
		return bodypic;
	}

	public void setBodypic(int bodypic[][]) {
		this.bodypic = bodypic;
	}

	public int getAvatar() {
		return avatar;
	}

	public void setAvatar(int avatar) {
		this.avatar = avatar;
	}

	public boolean equals(UserInfo compare) {
		if (compare.getIDNum() == IDNum) {
			return true;
		}
		return false;
	}
}
