package message;

public class MsgChatText extends MsgHead {
	private String msgText;

	public String getMsgText() {
		return msgText;
	}

	public void setMsgText(String msgText) {
		this.msgText = msgText;
	}

}
