package msg;

/*
 * ��½��Ϣ��
 */
public class MsgLogin extends MsgHead {
	private String pwd;

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
}
