package dataBase;

import client.ChatClient;
import friendListUI.AddFriendUI;
import friendListUI.FriendListUI;
import friendListUI.ListPane;

public class Figures {
	public static final int ServerID = 2000000000;// ��������ID
	public static final int LoginID = 2000000001;// ��½�����ID��
	public static ChatClient cc;
	public static int IDNum;
	public static int Pic;
	public static String NickName;
	public static ListPane list;
	public static AddFriendUI afu;
	public static FriendListUI flu;
}
